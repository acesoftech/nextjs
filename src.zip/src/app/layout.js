
import "./globals.css";
import "./style.css";
import "./m-style.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import Script from 'next/script';

export default function RootLayout({ children }) {
  return (
    <html lang="en">
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <Script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" strategy="beforeInteractive" />
    </head>
      <body>
      <div class="container-fluid">

      <nav class="navbar navbar-expand-lg navbar-light">
      <div class="container-fluid">
        <a class="navbar-brand" href="#">
        <img src="images/logo.png" class="logo" />
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        
    
        <div class="collapse navbar-collapse" id="navbarScroll">
          
    <div>
          <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style={{'--bs-scroll-height': '100px'}}>
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="#">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">About</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarScrollingDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Services
              </a>
              <ul class="dropdown-menu" aria-labelledby="navbarScrollingDropdown">
                <li><a class="dropdown-item" href="#">Retaurant</a></li>
                <li><a class="dropdown-item" href="#">Taxi To Airport</a></li>
                <li><a class="dropdown-item" href="#">Lounge</a></li>
                <li><hr class="dropdown-divider" /></li>
               
                <li><a class="dropdown-item" href="#">Cofee</a></li>
                <li><a class="dropdown-item" href="#">Rooms</a></li>
                <li><a class="dropdown-item" href="#">Wedding Halls</a></li>
              </ul>
            </li>
            <li class="nav-item">
              <a class="nav-link " href="#" tabindex="-1">Travel</a>
            </li>
    
             <li class="nav-item">
              <a class="nav-link " href="#" tabindex="-1" >Restaurant</a>
            </li>
    
            <li class="nav-item">
              <a class="nav-link " href="#" tabindex="-1">Contact</a>
            </li>
          </ul>
    
    </div>
    
    <div class="social_box">
      <ul>
      <li><i class="fa fa-facebook"></i></li>
      <li><i class="fa fa-instagram"></i></li>
      <li><i class="fa fa-twitter"></i></li>
      <li><i class="fa fa-whatsapp"></i></li>
      </ul>
    </div>
      </div>
      </div>
    </nav>

  <div class="menu_line"></div>


        {children}


 <footer class="container-fluid">
    <div class="container">
      
      <div class="row">
        <div class="col-md-4 footer_left" >
          <img src="images/footer_logo.jpg" />
          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
        </div>
        <div class="col-md-4 footer_center">
          <h3>Links</h3>
          <ul>
            <li><a href="">Home</a></li>
            <li><a href="">About</a></li>
            <li><a href="">Food</a></li>
            <li><a href="">Blog</a></li>
          </ul>
        </div>
  
         <div class="col-md-4 footer_right">
          <h3>Address</h3>
          <ul>
            <li><a href="">ABC road Kolakata</a></li>
            <li><a href="">enquiry@foodnjoy.com</a></li>
            <li><a href="">Mo: 8583959528</a></li>
          </ul>
        </div>
          
  
        </div>
      </div>
  
   
  </footer>

    </div>
      </body>
    </html>
  );
}
